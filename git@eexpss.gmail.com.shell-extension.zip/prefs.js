'use strict';

const { Adw, Gio, Gtk } = imports.gi;

const ExtensionUtils = imports.misc.extensionUtils;
const Me = ExtensionUtils.getCurrentExtension();


function init() {
}

function fillPreferencesWindow(window) {
    // Use the same GSettings schema as in `extension.js`
    const settings = ExtensionUtils.getSettings(
        'org.gnome.shell.extensions.weather');

    // Create a preferences page and group
    const page = new Adw.PreferencesPage();
    const group = new Adw.PreferencesGroup();
    page.add(group);
    group.add(add_row_entry("longitude"));
    group.add(add_row_entry("latitude"));

    window.add(page);

}

function add_row_entry(s){
	const row = new Adw.ActionRow({ title: _(s) });

	const entry = new Gtk.Entry({
			active: settings.get_number (s),
			valign: Gtk.Align.CENTER,
	});
	//~ settings.bind(
			//~ 'show-indicator',
			//~ entry,
			//~ 'active',
			//~ Gio.SettingsBindFlags.DEFAULT
	//~ );
	row.add_suffix(entry);
	row.activatable_widget = entry;
	return row;
}
